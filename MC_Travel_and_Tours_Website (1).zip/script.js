
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const WHATSAPP_NUMBER=''; // Add your business WhatsApp number with country code, digits only.
const menu=$('#menu-toggle'),nav=$('#primary-nav');
menu?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close navigation menu':'Open navigation menu')});
$$('.nav-link').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menu?.setAttribute('aria-expanded','false')}));
$('#current-year').textContent=new Date().getFullYear();
const topBtn=$('#back-to-top');window.addEventListener('scroll',()=>topBtn.classList.toggle('visible',scrollY>500));topBtn.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in-view');observer.unobserve(e.target)}}),{threshold:.08});$$('.reveal').forEach(el=>observer.observe(el));
const service=$('#booking-service'),destination=$('#booking-destination');
function setInquiry(s,d=''){if(service&&s){const opt=[...service.options].find(o=>o.text.toLowerCase()===s.toLowerCase()||o.text.toLowerCase().includes(s.toLowerCase()));if(opt)service.value=opt.value}if(destination&&d)destination.value=d;$('#booking').scrollIntoView({behavior:'smooth'})}
$$('.inquiry-link').forEach(b=>b.addEventListener('click',()=>setInquiry(b.dataset.service)));
$$('.quote-trigger').forEach(b=>b.addEventListener('click',()=>setInquiry('Sri Lanka Tour Packages',b.dataset.tour)));
$$('.bike-select').forEach(b=>b.addEventListener('click',()=>{const s=$('#rental-category');if(s)s.value=b.dataset.bike;$('#rental-form').scrollIntoView({behavior:'smooth',block:'center'})}));
$$('.destination-inquire').forEach(b=>b.addEventListener('click',()=>setInquiry('Customized Day Tours',b.dataset.destination)));
const messageDialog=$('#message-dialog'),prepared=$('#prepared-message'),copyStatus=$('#copy-status');
function showMessage(text){prepared.value=text;copyStatus.textContent='';messageDialog.showModal()}
$$('.whatsapp-trigger').forEach(b=>b.addEventListener('click',()=>showMessage(b.dataset.message||'Hello MC Travel & Tours. I would like to make an inquiry.')));
function formMessage(form,title){const data=new FormData(form);return `${title}\n\n`+[...data.entries()].filter(([k,v])=>v!=='').map(([k,v])=>`${k.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase())}: ${v}`).join('\n')+'\n\nPlease confirm availability and pricing.'}
function validate(form){let ok=true;$$('.field',form).forEach(w=>{const el=$('input,select,textarea',w),err=$('.field-error',w);if(!el)return;let msg='';if(el.required&&!el.value.trim())msg='This field is required.';else if(el.type==='email'&&el.value&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(el.value))msg='Enter a valid email address.';if(el.type==='date'&&el.value&&el.min&&el.value<el.min)msg='Choose a valid date.';if(err)err.textContent=msg;if(msg)ok=false});return ok}
function wireForm(id,status,title){const form=$('#'+id);form?.addEventListener('submit',e=>{e.preventDefault();const st=$('#'+status);if(!validate(form)){st.textContent='Please check the highlighted fields.';return}st.textContent='Your inquiry is prepared. Choose Copy Inquiry or WhatsApp to send it.';showMessage(formMessage(form,title))})}
wireForm('booking-form','booking-status','MC Travel & Tours — Trip Inquiry');
wireForm('rental-form','rental-status','MC Travel & Tours — Bike Rental Inquiry');
wireForm('contact-form','contact-status','MC Travel & Tours — Contact Message');
const pick=$('#pickup-date'),ret=$('#return-date'),estimate=$('#rental-estimate strong');
function updateDuration(){if(!pick||!ret||!estimate)return;ret.min=pick.value||'';if(pick.value&&ret.value&&ret.value>=pick.value){const days=Math.max(1,Math.round((new Date(ret.value+'T12:00:00')-new Date(pick.value+'T12:00:00'))/86400000));estimate.textContent=`${days} day${days===1?'':'s'} requested — price on request`}else estimate.textContent='Select valid pickup and return dates'}
pick?.addEventListener('change',updateDuration);ret?.addEventListener('change',updateDuration);
$('#copy-message').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(prepared.value);copyStatus.textContent='Inquiry copied. You can paste it into WhatsApp or email.'}catch{prepared.select();document.execCommand('copy');copyStatus.textContent='Inquiry selected/copied where supported.'}});
$('#open-whatsapp').addEventListener('click',()=>{if(!WHATSAPP_NUMBER){copyStatus.textContent='WhatsApp number is not configured yet. Copy the message and send it manually.';return}window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(prepared.value)}`,'_blank','noopener')});
$('#message-close').addEventListener('click',()=>messageDialog.close());
const gallery=[...$$('.gallery-item')].map(b=>({src:$('img',b).src,alt:$('img',b).alt,caption:$('span',b)?.textContent||$('img',b).alt}));let gi=0;const lightbox=$('#lightbox');
function showGallery(i){gi=(i+gallery.length)%gallery.length;$('#lightbox-image').src=gallery[gi].src;$('#lightbox-image').alt=gallery[gi].alt;$('#lightbox-caption').textContent=gallery[gi].caption}
$$('.gallery-item').forEach((b,i)=>b.addEventListener('click',()=>{showGallery(i);lightbox.showModal()}));
$('#lightbox-close').addEventListener('click',()=>lightbox.close());$('#lightbox-prev').addEventListener('click',()=>showGallery(gi-1));$('#lightbox-next').addEventListener('click',()=>showGallery(gi+1));
lightbox.addEventListener('click',e=>{if(e.target===lightbox)lightbox.close()});
document.addEventListener('keydown',e=>{if(!lightbox.open)return;if(e.key==='ArrowLeft')showGallery(gi-1);if(e.key==='ArrowRight')showGallery(gi+1)});
let slide=0;const track=$('#testimonial-track'),slides=$$('.testimonial-slide');function moveSlide(n){slide=(n+slides.length)%slides.length;track.style.transform=`translateX(-${slide*100}%)`;$('#testimonial-count').textContent=`${slide+1} / ${slides.length}`}$('#testimonial-prev').addEventListener('click',()=>moveSlide(slide-1));$('#testimonial-next').addEventListener('click',()=>moveSlide(slide+1));
const legal=$('#legal-dialog'),legalTitle=$('#legal-title'),legalContent=$('#legal-content');
$$('.legal-trigger').forEach(b=>b.addEventListener('click',()=>{const privacy=b.dataset.legal==='privacy';legalTitle.textContent=privacy?'Privacy Policy':'Terms & Conditions';legalContent.innerHTML=privacy?'<p>This demonstration website does not send form data to a server. Inquiry details are used locally to prepare a message for you to copy or send yourself.</p><p>Before publishing, update this policy to match the actual business, hosting, analytics, and data practices.</p>':'<p>All tour, transfer, and rental requests are inquiries only. A booking is confirmed only after the business confirms availability, final pricing, and applicable terms.</p><p>Replace this sample text with your business terms before publishing.</p>';legal.showModal()}));$('#legal-close').addEventListener('click',()=>legal.close());
