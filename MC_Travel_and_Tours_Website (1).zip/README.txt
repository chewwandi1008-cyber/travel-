MC TRAVEL & TOURS WEBSITE
========================

Files:
- index.html: website structure
- style.css: responsive design
- script.js: navigation, inquiry forms, bike date estimate, gallery, sample reviews slider

HOW TO VIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another browser.
3. Internet access is needed for remote photography, Google Fonts, and Font Awesome icons.

BEFORE PUBLISHING
- Replace placeholder telephone, email, address, social profiles, and map location in index.html.
- In script.js, set WHATSAPP_NUMBER to your business WhatsApp number using country code and digits only.
- Add real business details, prices, rental terms, and genuine customer reviews.
- Forms currently prepare inquiry text in the browser; they do not email or store submissions automatically.
- For a public website, upload the extracted files to a hosting provider such as GitHub Pages, Netlify, or your own web hosting.

This package is a ready-to-preview front-end website, not a hosted live domain.
